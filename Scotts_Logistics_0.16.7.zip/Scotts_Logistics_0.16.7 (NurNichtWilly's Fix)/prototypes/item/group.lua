

data:extend({
	{type = "item-subgroup",
	name = "drone-network",
	group = "logistics",
	order = "ff"
	},
	{type = "item-subgroup",
	name = "more-intermediates",
	group = "intermediate-products",
	order = "ff"}
	
	})