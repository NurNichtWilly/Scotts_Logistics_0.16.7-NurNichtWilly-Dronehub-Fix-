--item entity list.lua
require ("prototypes.colour")
require ("prototypes.entity.transport-belt-pictures")
require ("circuit-connector-sprites")
require ("prototypes.entity.extra-transport-belt-pictures")
tint_overclocked_inserter = {r=0.4,g=1,b=0.4}

tint_steel_sheet = {r=1,g=1,b=1}

tint_steel_pipe = {r=0.66,g=0.66,b=0.66}
tint_steel_sheet = {r=255, g=255, b=255}

data:extend(
{
	{ --Wooden-inserter
		type = "inserter",
		name = "wooden-inserter",
		icon = "__Scotts_Logistics__/graphics/icons/wooden-inserter.png",
		icon_size = 32,
		flags = {"placeable-neutral", "placeable-player", "player-creation"},
		minable = {hardness = 0.15, mining_time = 0.35, result = "wooden-inserter"},
		max_health = 50,
		corpse = "small-remnants",
		vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
		working_sound =
		{
		  match_progress_to_activity = true,
		  sound =
		  {
			{
			  filename = "__base__/sound/inserter-basic-1.ogg",
			  volume = 0.75
			},
			{
			  filename = "__base__/sound/inserter-basic-2.ogg",
			  volume = 0.75
			},
			{
			  filename = "__base__/sound/inserter-basic-3.ogg",
			  volume = 0.75
			},
			{
			  filename = "__base__/sound/inserter-basic-4.ogg",
			  volume = 0.75
			},
			{
			  filename = "__base__/sound/inserter-fast-5.ogg",
			  volume = 0.75
			}
		  }
		},
		collision_box = {{-0.15, -0.15}, {0.15, 0.15}},
		selection_box = {{-0.4, -0.35}, {0.4, 0.45}},
		energy_per_movement = 25,
		energy_per_rotation = 125,
		energy_source =
		{
		  type = "burner",
		  fuel_inventory_size = 1,
		  effectivity = 0.45,
		  fuel_category = "chemical"
		},
		extension_speed = 0.016,
		rotation_speed = 0.008,
		pickup_position = {0, -1},
		insert_position = {0, 1.2},
		fast_replaceable_group = "inserter",
		hand_base_picture =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/wooden-inserter-hand-base.png",
		  priority = "extra-high",
		  width = 8,
		  height = 34,
		  hr_version = {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-wooden-inserter-hand-base.png",
			priority = "extra-high",
			width = 32,
			height = 136,
			scale = 0.25
		  }
		},
		hand_closed_picture =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/wooden-inserter-hand-closed.png",
		  priority = "extra-high",
		  width = 18,
		  height = 41,
		  hr_version = {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-wooden-inserter-hand-closed.png",
			priority = "extra-high",
			width = 72,
			height = 164,
			scale = 0.25
		  }
		},
		hand_open_picture =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/wooden-inserter-hand-open.png",
		  priority = "extra-high",
		  width = 18,
		  height = 41,
		  hr_version = {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-wooden-inserter-hand-open.png",
			priority = "extra-high",
			width = 72,
			height = 164,
			scale = 0.25
		  }
		},
		platform_picture =
		{
		  sheet=
		  {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/wooden-inserter-platform.png",
			priority = "extra-high",
			width = 46,
			height = 46,
			shift = {0.09375, 0},
			hr_version = {
			  filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-wooden-inserter-platform.png",
			  priority = "extra-high",
			  width = 105,
			  height = 79,
			  shift = util.by_pixel(1.5, 7.5-1),
			  scale = 0.5
			}
		  }
		},
		hand_base_shadow =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/inserter-hand-base-shadow.png",
		  priority = "extra-high",
		  width = 8,
		  height = 34,
		  hr_version = {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-inserter-hand-base-shadow.png",
			priority = "extra-high",
			width = 32,
			height = 132,
			scale = 0.25
		  }
		},
		hand_closed_shadow =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/inserter-hand-closed-shadow.png",
		  priority = "extra-high",
		  width = 18,
		  height = 41,
		  hr_version = {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-inserter-hand-closed-shadow.png",
			priority = "extra-high",
			width = 72,
			height = 164,
			scale = 0.25
		  }
		},
		hand_open_shadow =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/inserter-hand-open-shadow.png",
		  priority = "extra-high",
		  width = 18,
		  height = 41,
		  hr_version = {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-inserter-hand-open-shadow.png",
			priority = "extra-high",
			width = 72,
			height = 164,
			scale = 0.25
		  }
		},
	 },
	 
	 
	{	--overclocked-inserter
		type = "inserter",
		name = "overclocked-inserter",
		icons = {{icon = "__Scotts_Logistics__/graphics/icons/overclocked-inserter.png", tint= tint_overclocked_inserter}},
		icon_size = 32,
		flags = {"placeable-neutral", "placeable-player", "player-creation"},
		minable = {hardness = 0.4, mining_time = 0.6, result = "overclocked-inserter"},
		max_health = 200,
		corpse = "small-remnants",
		vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
		working_sound =
		{
		  match_progress_to_activity = true,
		  sound =
		  {
			{
			  filename = "__base__/sound/inserter-basic-1.ogg",
			  volume = 0.75
			},
			{
			  filename = "__base__/sound/inserter-basic-2.ogg",
			  volume = 0.75
			},
			{
			  filename = "__base__/sound/inserter-basic-3.ogg",
			  volume = 0.75
			},
			{
			  filename = "__base__/sound/inserter-basic-4.ogg",
			  volume = 0.75
			},
			{
			  filename = "__base__/sound/inserter-fast-5.ogg",
			  volume = 0.75
			}
		  }
		},
		collision_box = {{-0.15, -0.15}, {0.15, 0.15}},
		selection_box = {{-0.4, -0.35}, {0.4, 0.45}},
		energy_per_movement = 8000,
		energy_per_rotation = 13000,
		energy_source =
		{
		  type = "electric",
		  power_drain = "0.9kW",
		  usage_priority = "secondary-input"
		},
		extension_speed = 0.09,
		rotation_speed = 0.07,
		pickup_position = {0, -1},
		insert_position = {0, 1.2},
		fast_replaceable_group = "inserter",
		hand_base_picture =
		{
		  filename = "__base__/graphics/entity/inserter/inserter-hand-base.png",
		  tint = tint_overclocked_inserter,
		  priority = "extra-high",
		  width = 8,
		  height = 34,
		  hr_version = {
			filename = "__base__/graphics/entity/inserter/hr-inserter-hand-base.png",
			tint = tint_overclocked_inserter,
			priority = "extra-high",
			width = 32,
			height = 136,
			scale = 0.25
		  }
		},
		hand_closed_picture =
		{
		  filename = "__base__/graphics/entity/inserter/inserter-hand-closed.png",
		  tint = tint_overclocked_inserter,
		  priority = "extra-high",
		  width = 18,
		  height = 41,
		  hr_version = {
			filename = "__base__/graphics/entity/inserter/hr-inserter-hand-closed.png",
			tint = tint_overclocked_inserter,
			priority = "extra-high",
			width = 72,
			height = 164,
			scale = 0.25
		  }
		},
		hand_open_picture =
		{
		  filename = "__base__/graphics/entity/inserter/inserter-hand-open.png",
		  tint = tint_overclocked_inserter,
		  priority = "extra-high",
		  width = 18,
		  height = 41,
		  hr_version = {
			filename = "__base__/graphics/entity/inserter/hr-inserter-hand-open.png",
			tint = tint_overclocked_inserter,
			priority = "extra-high",
			width = 72,
			height = 164,
			scale = 0.25
		  }
		},
		platform_picture =
		{
		  sheet=
		  {
			filename = "__base__/graphics/entity/inserter/inserter-platform.png",
			tint = tint_overclocked_inserter,
			priority = "extra-high",
			width = 46,
			height = 46,
			shift = {0.09375, 0},
			hr_version = {
			  filename = "__base__/graphics/entity/inserter/hr-inserter-platform.png",
			  tint = tint_overclocked_inserter,
			  priority = "extra-high",
			  width = 105,
			  height = 79,
			  shift = util.by_pixel(1.5, 7.5-1),
			  scale = 0.5
			}
		  }
		},
		hand_base_shadow =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/inserter-hand-base-shadow.png",
		  priority = "extra-high",
		  width = 8,
		  height = 34,
		  hr_version = {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-inserter-hand-base-shadow.png",
			priority = "extra-high",
			width = 32,
			height = 132,
			scale = 0.25
		  }
		},
		hand_closed_shadow =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/inserter-hand-closed-shadow.png",
		  priority = "extra-high",
		  width = 18,
		  height = 41,
		  hr_version = {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-inserter-hand-closed-shadow.png",
			priority = "extra-high",
			width = 72,
			height = 164,
			scale = 0.25
		  }
		},
		hand_open_shadow =
		{
		  filename = "__Scotts_Logistics__/graphics/entity/inserter/inserter-hand-open-shadow.png",
		  priority = "extra-high",
		  width = 18,
		  height = 41,
		  hr_version = 
		  {
			filename = "__Scotts_Logistics__/graphics/entity/inserter/hr-inserter-hand-open-shadow.png",
			priority = "extra-high",
			width = 72,
			height = 164,
			scale = 0.25
		  }
		},
	 },
	 
	 { -- overclocked-transport-belt
	 
			type = "transport-belt",
			name = "overclocked-transport-belt",
			icon = "__Scotts_Logistics__/graphics/icons/overclocked-transport-belt.png",
			icon_size = 32,
			flags = {"placeable-neutral", "player-creation"},
			minable = {hardness = 0.2, mining_time = 0.34, result = "overclocked-transport-belt"},
			max_health = 180,
			corpse = "small-remnants",
			resistances =
			{
			  {
				type = "fire",
				percent = 55
			  }
			},
			collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
			selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
			working_sound =
			{
			  sound =
			  {
				filename = "__base__/sound/fast-transport-belt.ogg",
				volume = 0.4
			  },
			  max_sounds_per_type = 3
			},
			animation_speed_coefficient = 32,
			animations =
			{
			  filename = "__Scotts_Logistics__/graphics/entity/belts/green-transport-belt.png",
			  priority = "extra-high",
			  width = 40,
			  height = 40,
			  frame_count = 32,
			  direction_count = 12,
			  hr_version =
			  {
				filename = "__Scotts_Logistics__/graphics/entity/belts/hr-green-transport-belt.png",
				priority = "extra-high",
				width = 80,
				height = 80,
				frame_count = 32,
				line_length = 16,
				direction_count = 12,
				scale = 0.5
			  }
			},
			belt_horizontal = fast_belt_horizontal, -- specified in transport-belt-pictures.lua
			belt_vertical = fast_belt_vertical,
			ending_top = fast_belt_ending_top,
			ending_bottom = fast_belt_ending_bottom,
			ending_side = fast_belt_ending_side,
			starting_top = fast_belt_starting_top,
			starting_bottom = fast_belt_starting_bottom,
			starting_side = fast_belt_starting_side,
			ending_patch = ending_patch_prototype,
			fast_replaceable_group = "transport-belt",
			speed = 0.078125,
			connector_frame_sprites = transport_belt_connector_frame_sprites,
			circuit_wire_connection_points = circuit_connector_definitions["belt"].points,
			circuit_connector_sprites = circuit_connector_definitions["belt"].sprites,
			circuit_wire_max_distance = transport_belt_circuit_wire_max_distance
		  
		},
	 { -- Overclocked underground-belt
			type = "underground-belt",
			name = "overclocked-underground-belt",
			icon = "__Scotts_Logistics__/graphics/icons/overclocked-underground-belt.png",
			icon_size = 32,
			flags = {"placeable-neutral", "player-creation"},
			minable = {hardness = 0.2, mining_time = 0.55, result = "overclocked-underground-belt"},
			max_health = 180,
			corpse = "small-remnants",
			max_distance = 9,
			underground_sprite =
			{
			  filename = "__core__/graphics/arrows/underground-lines.png",
			  priority = "high",
			  width = 64,
			  height = 64,
			  x = 64,
			  scale = 0.5
			},
			underground_remove_belts_sprite =
			{
			  filename = "__core__/graphics/arrows/underground-lines-remove.png",
			  priority = "high",
			  width = 64,
			  height = 64,
			  x = 64,
			  scale = 0.5
			},
			resistances =
			{
			  {
				type = "fire",
				percent = 60
			  },
			  {
				type = "impact",
				percent = 30
			  }
			},
			collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
			selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
			animation_speed_coefficient = 32,
			belt_horizontal = fast_belt_horizontal, -- specified in transport-belt-pictures.lua
			belt_vertical = fast_belt_vertical,
			ending_top = fast_belt_ending_top,
			ending_bottom = fast_belt_ending_bottom,
			ending_side = fast_belt_ending_side,
			starting_top = fast_belt_starting_top,
			starting_bottom = fast_belt_starting_bottom,
			starting_side = fast_belt_starting_side,
			fast_replaceable_group = "transport-belt",
			speed = 0.078125,
			structure =
			{
			  direction_in =
			  {
				sheet =
				{
				  filename = "__Scotts_Logistics__/graphics/entity/belts/green-underground-belt-structure.png",
				  priority = "extra-high",
				  shift = {0.26, 0},
				  width = 57,
				  height = 43,
				  y = 43,
				  hr_version =
				  {
					filename = "__Scotts_Logistics__/graphics/entity/belts/hr-green-underground-belt-structure.png",
					priority = "extra-high",
					shift = {0.15625, 0.0703125},
					width = 106,
					height = 85,
					y = 85,
					scale = 0.5
				  }
				}
			  },
			  direction_out =
			  {
				sheet =
				{
				  filename = "__Scotts_Logistics__/graphics/entity/belts/green-underground-belt-structure.png",
				  priority = "extra-high",
				  shift = {0.26, 0},
				  width = 57,
				  height = 43,
				  hr_version =
				  {
					filename = "__Scotts_Logistics__/graphics/entity/belts/hr-green-underground-belt-structure.png",
					priority = "extra-high",
					shift = {0.15625, 0.0703125},
					width = 106,
					height = 85,
					scale = 0.5
				  }
				}
			  }
			},
			ending_patch = ending_patch_prototype
			},
	
	{ --overclocked splitter
    type = "splitter",
    name = "overclocked-splitter",
    icon = "__Scotts_Logistics__/graphics/icons/overclocked-splitter.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "overclocked-splitter"},
    max_health = 200,
    corpse = "medium-remnants",
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
		collision_box = {{-0.9, -0.4}, {0.9, 0.4}},
		selection_box = {{-0.9, -0.5}, {0.9, 0.5}},
		animation_speed_coefficient = 32,
		structure_animation_speed_coefficient = 1.2,
		structure_animation_movement_cooldown = 10,
		belt_horizontal = fast_belt_horizontal, -- specified in transport-belt-pictures.lua
		belt_vertical = fast_belt_vertical,
		ending_top = fast_belt_ending_top,
		ending_bottom = fast_belt_ending_bottom,
		ending_side = fast_belt_ending_side,
		starting_top = fast_belt_starting_top,
		starting_bottom = fast_belt_starting_bottom,
		starting_side = fast_belt_starting_side,
		fast_replaceable_group = "transport-belt",
		speed = 0.078125,
		structure =
    {
      north =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/green-splitter-north.png",
        frame_count = 32,
        line_length = 16,
        priority = "extra-high",
        width = 83,
        height = 36,
        shift = {0.265625, 0},
        hr_version =
        {
          filename = "__Scotts_Logistics__/graphics/entity/belts/hr-green-splitter-north.png",
          frame_count = 32,
          line_length = 8,
          priority = "extra-high",
          width = 164,
          height = 70,
          shift = {0.25, 0.046875},
          scale = 0.5
        }
      },
      east =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/green-splitter-east.png",
        frame_count = 32,
        line_length = 16,
        priority = "extra-high",
        width = 46,
        height = 81,
        shift = {0.109375, -0.03125},
        hr_version =
        {
          filename = "__Scotts_Logistics__/graphics/entity/belts/hr-green-splitter-east.png",
          frame_count = 32,
          line_length = 8,
          priority = "extra-high",
          width = 93,
          height = 154,
          shift = {0.148438, -0.179688},
          scale = 0.5
        }
      },
      south =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/green-splitter-south.png",
        frame_count = 32,
        line_length = 16,
        priority = "extra-high",
        width = 85,
        height = 35,
        shift = {0.140625, -0.015625},
        hr_version =
        {
          filename = "__Scotts_Logistics__/graphics/entity/belts/hr-green-splitter-south.png",
          frame_count = 32,
          line_length = 8,
          priority = "extra-high",
          width = 168,
          height = 67,
          shift = {0.140625, 0.0234375},
          scale = 0.5
        }
      },
      west =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/green-splitter-west.png",
        frame_count = 32,
        line_length = 16,
        priority = "extra-high",
        width = 46,
        height = 81,
        shift = {0.296875, -0.03125},
        hr_version =
        {
          filename = "__Scotts_Logistics__/graphics/entity/belts/hr-green-splitter-west.png",
          frame_count = 32,
          line_length = 8,
          priority = "extra-high",
          width = 94,
          height = 154,
          shift = {0.203125, -0.109375},
          scale = 0.5
        }
      }
    },
    ending_patch = ending_patch_prototype
  },

	{ --overclocked-furnace
	type = "furnace",
    name = "overclocked-furnace",
    icon = "__Scotts_Logistics__/graphics/icons/overclocked-furnace.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 1, result = "overclocked-furnace"},
    max_health = 370,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    resistances =
    {
      {
        type = "fire",
        percent = 80
      }
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    module_specification =
    {
      module_slots = 3,
      module_info_icon_shift = {0, 0.8}
    },
    allowed_effects = {"consumption", "speed", "productivity", "pollution"},
    crafting_categories = {"smelting"},
    result_inventory_size = 1,
    crafting_speed = 3,
    energy_usage = "350kW",
    source_inventory_size = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.01
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/electric-furnace.ogg",
        volume = 0.7
      },
      apparent_volume = 1.5
    },
    animation =
    {
      layers =
      {
        {
          filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/electric-furnace-base.png",
		  priority = "high",
          width = 129,
          height = 100,
          frame_count = 1,
          shift = {0.421875, 0},
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/hr-electric-furnace.png",
			priority = "high",
            width = 239,
            height = 219,
            frame_count = 1,
            shift = util.by_pixel(0.75, 5.75),
            scale = 0.5
          }
        },
        {
          filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/electric-furnace-shadow.png",
          priority = "high",
          width = 129,
          height = 100,
          frame_count = 1,
          shift = {0.421875, 0},
          draw_as_shadow = true,
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/hr-electric-furnace-shadow.png",
            priority = "high",
            width = 227,
            height = 171,
            frame_count = 1,
            draw_as_shadow = true,
            shift = util.by_pixel(11.25, 7.75),
            scale = 0.5
          }
        }
      }
    },
    working_visualisations =
    {
      {
        animation =
        {
          filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/electric-furnace-heater.png",
          priority = "high",
          width = 25,
          height = 15,
          frame_count = 12,
          animation_speed = 0.5,
          shift = {0.015625, 0.890625},
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/hr-electric-furnace-heater.png",
            priority = "high",
            width = 60,
            height = 56,
            frame_count = 12,
            animation_speed = 0.5,
            shift = util.by_pixel(1.75, 32.75),
            scale = 0.5
          }
        },
        light = {intensity = 0.4, size = 6, shift = {0.0, 1.0}, color = {r = 1.0, g = 1.0, b = 1.0}}
      },
      {
        animation =
        {
          filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/electric-furnace-propeller-1.png",
          priority = "high",
          width = 19,
          height = 13,
          frame_count = 4,
          animation_speed = 0.5,
          shift = {-0.671875, -0.640625},
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/hr-electric-furnace-propeller-1.png",
            priority = "high",
            width = 37,
            height = 25,
            frame_count = 4,
            animation_speed = 0.5,
            shift = util.by_pixel(-20.5, -18.5),
            scale = 0.5
          }
        }
      },
      {
        animation =
        {
          filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/electric-furnace-propeller-2.png",
		  priority = "high",
          width = 12,
          height = 9,
          frame_count = 4,
          animation_speed = 0.5,
          shift = {0.0625, -1.234375},
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/electric-furnace/hr-electric-furnace-propeller-2.png",
            priority = "high",
            width = 23,
            height = 15,
            frame_count = 4,
            animation_speed = 0.5,
            shift = util.by_pixel(3.5, -38),
            scale = 0.5
          }
        }
      }
    },
    fast_replaceable_group = "furnace"
	
	},
	
	{ --overclocked-assembling-machine
    type = "assembling-machine",
    name = "overclocked-assembling-machine",
    icon = "__Scotts_Logistics__/graphics/icons/overclocked-assembling-machine.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.55, result = "overclocked-assembling-machine"},
    max_health = 370,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    alert_icon_shift = util.by_pixel(-3, -12),
    resistances =
    {
      {
        type = "fire",
        percent = 70
      }
    },
    fluid_boxes =
    {
      {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {0, -2} }},
        secondary_draw_orders = { north = -1 }
      },
      {
        production_type = "output",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = 1,
        pipe_connections = {{ type="output", position = {0, 2} }},
        secondary_draw_orders = { north = -1 }
      },
      off_when_no_fluid_recipe = true
    },
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    fast_replaceable_group = "assembling-machine",
    animation =
    {
      layers =
      {
        {
          filename = "__Scotts_Logistics__/graphics/entity/assembling-machine-2/assembling-machine-2.png",
          priority = "high",
          width = 108,
          height = 110,
          frame_count = 32,
          line_length = 8,
          shift = util.by_pixel(0, 4),
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/assembling-machine-2/hr-assembling-machine-2.png",
			priority = "high",
            width = 214,
            height = 218,
            frame_count = 32,
            line_length = 8,
            shift = util.by_pixel(0, 4),
            scale = 0.5
          }
        },
        {
          filename = "__Scotts_Logistics__/graphics/entity/assembling-machine-2/assembling-machine-2-shadow.png",
		  priority = "high",
          width = 98,
          height = 82,
          frame_count = 32,
          line_length = 8,
          draw_as_shadow = true,
          shift = util.by_pixel(12, 5),
          hr_version =
          {
            filename = "__Scotts_Logistics__/graphics/entity/assembling-machine-2/hr-assembling-machine-2-shadow.png",
            priority = "high",
            width = 196,
            height = 163,
            frame_count = 32,
            line_length = 8,
            draw_as_shadow = true,
            shift = util.by_pixel(12, 4.75),
            scale = 0.5
          }
        }
      }
    },
    open_sound = { filename = "__base__/sound/machine-open.ogg", volume = 0.85 },
    close_sound = { filename = "__base__/sound/machine-close.ogg", volume = 0.75 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        {
          filename = "__base__/sound/assembling-machine-t2-1.ogg",
          volume = 0.8
        },
        {
          filename = "__base__/sound/assembling-machine-t2-2.ogg",
          volume = 0.8
        }
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5
    },
    crafting_categories = {"crafting", "advanced-crafting", "crafting-with-fluid"},
    crafting_speed = 1,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.06 / 3
    },
    energy_usage = "225kW",
    ingredient_count = 4,
    module_specification =
    {
      module_slots = 3
    },
    allowed_effects = {"consumption", "speed", "productivity", "pollution"}
  },
  
  { -- steel-pipe
    type = "pipe",
    name = "steel-pipe",
    icons = {{icon= "__base__/graphics/icons/pipe.png", tint = tint_steel_pipe}},
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "steel-pipe"},
    max_health = 200,
    corpse = "small-remnants",
    resistances =
    {
      {
        type = "fire",
        percent = 80
      },
      {
        type = "impact",
        percent = 30
      }
    },
    fast_replaceable_group = "pipe",
    collision_box = {{-0.29, -0.29}, {0.29, 0.29}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    fluid_box =
    {
      base_area = 2,
      pipe_connections = 
	  { 
		{position = {0,1} },
		{position = {0,-1} },
		{position = {0,-1} },
		{position = {1,0} },
		{position = {-1,0} }
	  }
      
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    pictures = pipepictures(),
    working_sound =
    {
      sound =
      {
        {
          filename = "__base__/sound/pipe.ogg",
          volume = 0.85
        }
      },
      match_volume_to_activity = true,
      max_sounds_per_type = 3
    },

    horizontal_window_bounding_box = {{-0.25, -0.28125}, {0.25, 0.15625}},
    vertical_window_bounding_box = {{-0.28125, -0.5}, {0.03125, 0.125}}
  },
  
    { -- steel-pipe-to-ground
    type = "pipe-to-ground",
    name = "steel-pipe-to-ground",
    icons = {{icon = "__base__/graphics/icons/pipe-to-ground.png",tint = tint_steel_pipe}},
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "steel-pipe-to-ground"},
    max_health = 200,
    corpse = "small-remnants",
    resistances =
    {
      {
        type = "fire",
        percent = 80
      },
      {
        type = "impact",
        percent = 40
      }

    },
    collision_box = {{-0.29, -0.29}, {0.29, 0.2}},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    fluid_box =
    {
      base_area = 2,
      pipe_covers = pipecoverspictures(),
      pipe_connections =
      {
        { position = {0, -1} },
        {
          position = {0, 1},
          max_underground_distance = 20
        }
      }
    },
    underground_sprite =
    {
      filename = "__core__/graphics/arrows/underground-lines.png",
      priority = "extra-high-no-scale",
      width = 64,
      height = 64,
      scale = 0.5
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    pictures =
    {
      up =
      {
        filename = "__base__/graphics/entity/pipe-to-ground/pipe-to-ground-up.png",
		tint = tint_steel_sheet,
        priority = "high",
        width = 64,
        height = 64, --, shift = {0.10, -0.04}
        hr_version =
        {
           filename = "__base__/graphics/entity/pipe-to-ground/hr-pipe-to-ground-up.png",
		   tint = tint_steel_sheet,
           priority = "extra-high",
           width = 128,
           height = 128,
           scale = 0.5
        }
      },
      down =
      {
        filename = "__base__/graphics/entity/pipe-to-ground/pipe-to-ground-down.png",
		tint = tint_steel_sheet,
        priority = "high",
        width = 64,
        height = 64, --, shift = {0.05, 0}
        hr_version =
        {
           filename = "__base__/graphics/entity/pipe-to-ground/hr-pipe-to-ground-down.png",
		   tint = tint_steel_sheet,
           priority = "extra-high",
           width = 128,
           height = 128,
           scale = 0.5
        }
      },
      left =
      {
        filename = "__base__/graphics/entity/pipe-to-ground/pipe-to-ground-left.png",
		tint = tint_steel_sheet,
        priority = "high",
        width = 64,
        height = 64, --, shift = {-0.12, 0.1}
        hr_version =
        {
           filename = "__base__/graphics/entity/pipe-to-ground/hr-pipe-to-ground-left.png",
		   tint = tint_steel_sheet,
           priority = "extra-high",
           width = 128,
           height = 128,
           scale = 0.5
        }
      },
      right =
      {
        filename = "__base__/graphics/entity/pipe-to-ground/pipe-to-ground-right.png",
		tint = tint_steel_sheet,
        priority = "high",
        width = 64,
        height = 64, --, shift = {0.1, 0.1}
        hr_version =
        {
           filename = "__base__/graphics/entity/pipe-to-ground/hr-pipe-to-ground-right.png",
		   tint = tint_steel_sheet,
           priority = "extra-high",
           width = 128,
           height = 128,
           scale = 0.5
        }
      }
    }
  },
		{ --storage tank
    type = "storage-tank",
    name = "storage-tank",
    icon = "__base__/graphics/icons/storage-tank.png",
    icon_size = 32,
    flags = {"placeable-player", "player-creation"},
    minable = {mining_time = 1.5, result = "storage-tank"},
    max_health = 500,
    corpse = "medium-remnants",
    collision_box = {{-1.3, -1.3}, {1.3, 1.3}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    fluid_box =
    {
      base_area = 500,
      pipe_covers = pipecoverspictures(),
      pipe_connections =
      {
        { position = {-1, -2} },
        { position = {2, 1} },
        { position = {1, 2} },
        { position = {-2, -1} }
      }
    },
    two_direction_only = true,
    window_bounding_box = {{-0.125, 0.6875}, {0.1875, 1.1875}},
    pictures =
    {
      picture =
      {
        sheets =
        {
          {
            filename = "__base__/graphics/entity/storage-tank/storage-tank.png",
            priority = "extra-high",
            frames = 2,
            width = 110,
            height = 108,
            shift = util.by_pixel(0, 4),
            hr_version =
            {
              filename = "__base__/graphics/entity/storage-tank/hr-storage-tank.png",
              priority = "extra-high",
              frames = 2,
              width = 219,
              height = 215,
              shift = util.by_pixel(-0.25, 3.75),
              scale = 0.5
            }
          },
          {
            filename = "__base__/graphics/entity/storage-tank/storage-tank-shadow.png",
            priority = "extra-high",
            frames = 2,
            width = 146,
            height = 77,
            shift = util.by_pixel(30, 22.5),
            draw_as_shadow = true,
            hr_version =
            {
              filename = "__base__/graphics/entity/storage-tank/hr-storage-tank-shadow.png",
              priority = "extra-high",
              frames = 2,
              width = 291,
              height = 153,
              shift = util.by_pixel(29.75, 22.25),
              scale = 0.5,
              draw_as_shadow = true
            }
          }
        }
      },
      fluid_background =
      {
        filename = "__base__/graphics/entity/storage-tank/fluid-background.png",
        priority = "extra-high",
        width = 32,
        height = 15
      },
      window_background =
      {
        filename = "__base__/graphics/entity/storage-tank/window-background.png",
        priority = "extra-high",
        width = 17,
        height = 24,
        hr_version =
        {
          filename = "__base__/graphics/entity/storage-tank/hr-window-background.png",
          priority = "extra-high",
          width = 34,
          height = 48,
          scale = 0.5
        }
      },
      flow_sprite =
      {
        filename = "__base__/graphics/entity/pipe/fluid-flow-low-temperature.png",
        priority = "extra-high",
        width = 160,
        height = 20
      },
      gas_flow =
      {
        filename = "__base__/graphics/entity/pipe/steam.png",
        priority = "extra-high",
        line_length = 10,
        width = 24,
        height = 15,
        frame_count = 60,
        axially_symmetrical = false,
        direction_count = 1,
        animation_speed = 0.25,
        hr_version =
        {
          filename = "__base__/graphics/entity/pipe/hr-steam.png",
          priority = "extra-high",
          line_length = 10,
          width = 48,
          height = 30,
          frame_count = 60,
          axially_symmetrical = false,
          animation_speed = 0.25,
          direction_count = 1
        }
      }
    },
    flow_length_in_ticks = 360,
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
          filename = "__base__/sound/storage-tank.ogg",
          volume = 0.8
      },
      match_volume_to_activity = true,
      apparent_volume = 1.5,
      max_sounds_per_type = 3
    },

    circuit_wire_connection_points = circuit_connector_definitions["storage-tank"].points,
    circuit_connector_sprites = circuit_connector_definitions["storage-tank"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
  
  	 { -- primitive-transport-belt
	 
			type = "transport-belt",
			name = "primitive-transport-belt",
			icon = "__Scotts_Logistics__/graphics/icons/primitive-transport-belt.png",
			icon_size = 32,
			flags = {"placeable-neutral", "player-creation"},
			minable = {hardness = 0.2, mining_time = 0.14, result = "primitive-transport-belt"},
			max_health = 75,
			corpse = "small-remnants",
			resistances =
			{
			  {
				type = "fire",
				percent = 55
			  }
			},
			collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
			selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
			working_sound =
			{
			  sound =
			  {
				filename = "__base__/sound/fast-transport-belt.ogg",
				volume = 0.4
			  },
			  max_sounds_per_type = 3
			},
			animation_speed_coefficient = 32,
			animations =
			{
			  filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
			  priority = "extra-high",
			  width = 40,
			  height = 40,
			  frame_count = 16,
			  direction_count = 12,
			  hr_version =
			  {
				filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
				priority = "extra-high",
				width = 80,
				height = 80,
				frame_count = 16,
				line_length = 16,
				direction_count = 12,
				scale = 0.5
			  }
			},
			belt_horizontal = black_belt_horizontal, -- specified in transport-belt-pictures.lua
			belt_vertical = black_belt_vertical,
			ending_top = black_belt_ending_top,
			ending_bottom = black_belt_ending_bottom,
			ending_side = black_belt_ending_side,
			starting_top = black_belt_starting_top,
			starting_bottom = black_belt_starting_bottom,
			starting_side = black_belt_starting_side,
			ending_patch = ending_patch_prototype,
			fast_replaceable_group = "transport-belt",
			speed = 0.015625,
			connector_frame_sprites = transport_belt_connector_frame_sprites,
			circuit_wire_connection_points = circuit_connector_definitions["belt"].points,
			circuit_connector_sprites = circuit_connector_definitions["belt"].sprites,
			circuit_wire_max_distance = transport_belt_circuit_wire_max_distance
		  
		},
	 { -- primitive underground-belt
			type = "underground-belt",
			name = "primitive-underground-belt",
			icon = "__Scotts_Logistics__/graphics/icons/primitive-underground-belt.png",
			icon_size = 32,
			flags = {"placeable-neutral", "player-creation"},
			minable = {hardness = 0.2, mining_time = 0.2, result = "primitive-underground-belt"},
			max_health = 180,
			corpse = "small-remnants",
			max_distance = 2,
			underground_sprite =
			{
			  filename = "__core__/graphics/arrows/underground-lines.png",
			  priority = "high",
			  width = 64,
			  height = 64,
			  x = 64,
			  scale = 0.5
			},
			underground_remove_belts_sprite =
			{
			  filename = "__core__/graphics/arrows/underground-lines-remove.png",
			  priority = "high",
			  width = 64,
			  height = 64,
			  x = 64,
			  scale = 0.5
			},
			resistances =
			{
			  {
				type = "fire",
				percent = 60
			  },
			  {
				type = "impact",
				percent = 30
			  }
			},
			collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
			selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
			animation_speed_coefficient = 32,
			belt_horizontal = black_belt_horizontal, -- specified in transport-belt-pictures.lua
			belt_vertical = black_belt_vertical,
			ending_top = black_belt_ending_top,
			ending_bottom = black_belt_ending_bottom,
			ending_side = black_belt_ending_side,
			starting_top = black_belt_starting_top,
			starting_bottom = black_belt_starting_bottom,
			starting_side = black_belt_starting_side,
			fast_replaceable_group = "transport-belt",
			speed = 0.015625,
			structure =
			{
			  direction_in =
			  {
				sheet =
				{
				  filename = "__Scotts_Logistics__/graphics/entity/belts/black-underground-belt-structure.png",
				  priority = "extra-high",
				  shift = {0.26, 0},
				  width = 57,
				  height = 43,
				  y = 43,
				  hr_version =
				  {
					filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-underground-belt-structure.png",
					priority = "extra-high",
					shift = {0.15625, 0.0703125},
					width = 106,
					height = 85,
					y = 85,
					scale = 0.5
				  }
				}
			  },
			  direction_out =
			  {
				sheet =
				{
				  filename = "__Scotts_Logistics__/graphics/entity/belts/black-underground-belt-structure.png",
				  priority = "extra-high",
				  shift = {0.26, 0},
				  width = 57,
				  height = 43,
				  hr_version =
				  {
					filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-underground-belt-structure.png",
					priority = "extra-high",
					shift = {0.15625, 0.0703125},
					width = 106,
					height = 85,
					scale = 0.5
				  }
				}
			  }
			},
			ending_patch = ending_patch_prototype
			},
	
	{ --primitive splitter
    type = "splitter",
    name = "primitive-splitter",
    icon = "__Scotts_Logistics__/graphics/icons/primitive-splitter.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.2, result = "primitive-splitter"},
    max_health = 75,
    corpse = "medium-remnants",
    resistances =
    {
      {
        type = "fire",
        percent = 60
      }
    },
		collision_box = {{-0.9, -0.4}, {0.9, 0.4}},
		selection_box = {{-0.9, -0.5}, {0.9, 0.5}},
		animation_speed_coefficient = 32,
		structure_animation_speed_coefficient = 1.2,
		structure_animation_movement_cooldown = 10,
		belt_horizontal = black_belt_horizontal, -- specified in transport-belt-pictures.lua
		belt_vertical = black_belt_vertical,
		ending_top = black_belt_ending_top,
		ending_bottom = black_belt_ending_bottom,
		ending_side = black_belt_ending_side,
		starting_top = black_belt_starting_top,
		starting_bottom = black_belt_starting_bottom,
		starting_side = black_belt_starting_side,
		fast_replaceable_group = "transport-belt",
		speed = 0.015625,
		structure =
    {
      north =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/black-splitter-north.png",
        frame_count = 32,
        line_length = 16,
        priority = "extra-high",
        width = 83,
        height = 36,
        shift = {0.265625, 0},
        hr_version =
        {
          filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-splitter-north.png",
          frame_count = 32,
          line_length = 8,
          priority = "extra-high",
          width = 164,
          height = 70,
          shift = {0.25, 0.046875},
          scale = 0.5
        }
      },
      east =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/black-splitter-east.png",
        frame_count = 32,
        line_length = 16,
        priority = "extra-high",
        width = 51,
        height = 80,
        shift = {0.109375, -0.03125},
        hr_version =
        {
          filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-splitter-east.png",
          frame_count = 32,
          line_length = 8,
          priority = "extra-high",
          width = 93,
          height = 157,
          shift = {0.148438, -0.179688},
          scale = 0.5
        }
      },
      south =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/black-splitter-south.png",
        frame_count = 32,
        line_length = 16,
        priority = "extra-high",
        width = 85,
        height = 35,
        shift = {0.140625, -0.015625},
        hr_version =
        {
          filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-splitter-south.png",
          frame_count = 32,
          line_length = 8,
          priority = "extra-high",
          width = 168,
          height = 67,
          shift = {0.140625, 0.0234375},
          scale = 0.5
        }
      },
      west =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/black-splitter-west.png",
        frame_count = 32,
        line_length = 16,
        priority = "extra-high",
        width = 51,
        height = 78,
        shift = {0.296875, -0.03125},
        hr_version =
        {
          filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-splitter-west.png",
          frame_count = 32,
          line_length = 8,
          priority = "extra-high",
          width = 94,
          height = 154,
          shift = {0.203125, -0.109375},
          scale = 0.5
        }
      }
    },
    ending_patch = ending_patch_prototype
  },

}
)

 
