ending_patch_prototype =
  {
    sheet =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/start-end-integration-patches.png",
      width = 40,
      height = 40,
      priority = "extra-high",
      hr_version =
      {
        filename = "__Scotts_Logistics__/graphics/entity/belts/hr-start-end-integration-patches.png",
        width = 80,
        height = 80,
        priority = "extra-high",
        scale = 0.5
      }
    }
  }


---------------------- black BELT PICTURES
black_belt_horizontal =
  {
    filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 16,
    hr_version =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
      priority = "extra-high",
      width = 80,
      height = 80,
      frame_count = 16,
      scale = 0.5
    }
  }
black_belt_vertical =
  {
    filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 16,
    y = 40,
    hr_version =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
      priority = "extra-high",
      width = 80,
      height = 80,
      frame_count = 16,
      y = 80,
      scale = 0.5
    }
  }
black_belt_ending_top =
  {
    filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 16,
    y = 80,
    hr_version =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
      priority = "extra-high",
      width = 80,
      height = 80,
      frame_count = 16,
      y = 160,
      scale = 0.5
    }
  }
black_belt_ending_bottom =
  {
    filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 16,
    y = 120,
    hr_version =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
      priority = "extra-high",
      width = 80,
      height = 80,
      frame_count = 16,
      y = 240,
      scale = 0.5
    }
  }
black_belt_ending_side =
  {
    filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 16,
    y = 160,
    hr_version =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
      priority = "extra-high",
      width = 80,
      height = 80,
      frame_count = 16,
      y = 320,
      scale = 0.5
    }
  }
black_belt_starting_top =
  {
    filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 16,
    y = 200,
    hr_version =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
      priority = "extra-high",
      width = 80,
      height = 80,
      frame_count = 16,
      y = 400,
      scale = 0.5
    }
  }
black_belt_starting_bottom =
  {
    filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 16,
    y = 240,
    hr_version =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
      priority = "extra-high",
      width = 80,
      height = 80,
      frame_count = 16,
      y = 480,
      scale = 0.5
    }
  }
black_belt_starting_side =
  {
    filename = "__Scotts_Logistics__/graphics/entity/belts/black-transport-belt.png",
    priority = "extra-high",
    width = 40,
    height = 40,
    frame_count = 16,
    y = 280,
    hr_version =
    {
      filename = "__Scotts_Logistics__/graphics/entity/belts/hr-black-transport-belt.png",
      priority = "extra-high",
      width = 80,
      height = 80,
      frame_count = 16,
      y = 560,
      scale = 0.5
    }
  }


