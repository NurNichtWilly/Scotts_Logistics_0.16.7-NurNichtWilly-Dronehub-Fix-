--item-recipe list.lua
-- every item that needs to be crafted goes here. if enabled = false, there should be a technology to unlock it.

--replace testing = false BEFORE publication
testing = false
data:extend(
{
	{	
		type = "recipe",
		name = "wooden-inserter",
		enabled = true,
		ingredients =
		{
			{"wood", 2},
			{"iron-plate", 1}
		},
		result = "wooden-inserter",
		result_count = 2
	},
	
	{
		type = "recipe",
		name = "drone-frame",
		enabled = testing,
		energy_required = 15,
		ingredients = 
		{	
			{"iron-plate", 4},
			{"copper-plate", 2}
		},
		result = "drone-frame"
	},
	{	
		type = "recipe",
		name = "construction-drone",
		enabled = testing,
		ingredients = 
		{	
			{"drone-frame", 1},
			{"iron-battery", 2}
		},
		result = "construction-drone"
	},
	{
		type = "recipe",
		name = "iron-battery",
		enabled = testing,
		energy_required = 2,
		ingredients =
		{
			{"iron-plate", 2},
			{"copper-cable", 3}
		},
		result = "iron-battery"
	},

	
	{
		type = "recipe",
		name = "logistic-drone-chest-storage",
		enabled = testing,
		ingredients =
		{
		  {"iron-chest", 1},
		  {"electronic-circuit", 5},
		  {"iron-plate", 10}
		},
		result = "logistic-drone-chest-storage"
	},

	 {
		type = "recipe",
		name = "logistic-drone-chest-passive-provider",
		enabled = testing,
		ingredients =
		{
		  {"iron-chest", 1},
		  {"electronic-circuit", 5},
		  {"iron-plate", 10}
		},
		result = "logistic-drone-chest-passive-provider"
	  },
	  
	  {
		type = "recipe",
		name = "drone-port",
		enabled = testing,
		energy_required = 10,
		ingredients =
		{
		  {"logistic-drone-chest-passive-provider", 1},
		  {"logistic-drone-chest-storage", 1},
		  {"electronic-circuit", 50},
		  {"iron-plate", 50}
		},
		result = "drone-port"
	},
	{ --OVERCLOCKING
	type = "recipe",
		name = "overclocked-circuit",
		enabled = testing,
		ingredients =
		{
		  {"electronic-circuit", 4},
		  {"copper-cable", 6},
		  {"steel-sheet", 1},
		  
		},
		result = "overclocked-circuit",
		result_count = 2
	},
	{	
		type = "recipe",
		name = "overclocked-inserter",
		enabled = testing,
		ingredients =
		{
			{"overclocked-circuit", 1},
			{"fast-inserter", 1}
		},
		result = "overclocked-inserter",
		requester_paste_multiplier = 4
	},
	{	
		type = "recipe",
		name = "overclocked-transport-belt",
		enabled = testing,
		ingredients =
		{
			{"overclocked-circuit", 1},
			{"fast-transport-belt", 2},
			{"iron-gear-wheel",4}
		},
		result = "overclocked-transport-belt",
		result_count = 2,
		requester_paste_multiplier = 4
	},
	{	
		type = "recipe",
		name = "overclocked-underground-belt",
		energy_required = 1,
		enabled = testing,
		ingredients =
		{
			{"overclocked-circuit", 2},
			{"fast-underground-belt", 2},
			{"fast-transport-belt", 2}
		},
		result = "overclocked-underground-belt",
		result_count = 2,
		requester_paste_multiplier = 4
	},
	
	{	
		type = "recipe",
		name = "overclocked-splitter",
		energy_required = 1,
		enabled = testing,
		ingredients =
		{
			{"overclocked-circuit", 3},
			{"fast-splitter", 1},
			{"steel-sheet", 4}
		},
		result = "overclocked-splitter",
		requester_paste_multiplier = 4
	},
	{
		type = "recipe",
		name = "overclocked-furnace",
		energy_required = 3,
		enabled = testing,
		ingredients =
		{
			{"overclocked-circuit", 4},
			{"electric-furnace",1},
			{"steel-sheet",10}
		},
		result = "overclocked-furnace",
		requester_paste_multiplier = 4
	},
	{
		type = "recipe",
		name = "steel-sheet",
		energy_required = 16,
		category = "smelting",
		enabled = testing,
		ingredients = {{"steel-plate",3}},
		result = "steel-sheet",
		result_count = 4
		},
	{
		type = "recipe",
		name = "overclocked-assembling-machine",
		energy_required = 5,
		enabled = testing,
		ingredients =
		{
			{"overclocked-circuit", 7},
			{"assembling-machine-2",1},
			{"steel-sheet",14}
		},
		result = "overclocked-assembling-machine",
		requester_paste_multiplier = 4
	
	},
	{
		type = "recipe",
		name = "steel-pipe",
		enabled = testing,
		ingredients = 
		{
			{"steel-sheet",1}
		},
		result = "steel-pipe"
	},
	{
		type = "recipe",
		name = "steel-pipe-to-ground",
		enabled = testing,
		ingredients = 
		{
			{"steel-sheet",8},
			{"steel-pipe",20}
		},
		result = "steel-pipe-to-ground",
		result_count = 2
	},
	
	{
    type = "recipe",
    name = "storage-tank",
    energy_required = 3,
    enabled = false,
    ingredients =
    {
      {"iron-plate", 10},
      {"steel-sheet", 10}
    },
    result= "storage-tank"
  },
  {
    type = "recipe",
    name = "empty-barrel",
    category = "crafting",
    energy_required = 1,
    subgroup = "intermediate-product",
    enabled = false,
    ingredients =
    {
      {type="item", name="steel-sheet", amount=2}
    },
    results=
    {
      {type="item", name="empty-barrel", amount=1}
    }
  },
  {
    type = "recipe",
    name = "refined-concrete",
    energy_required = 15,
    enabled = false,
    category = "crafting-with-fluid",
    ingredients =
    {
      {"concrete", 20},
      {"iron-stick", 8},
      {"steel-sheet", 1},
      {type="fluid", name="water", amount=100}
    },
    result= "refined-concrete",
    result_count = 20
  },
	{
    type = "recipe",
    name = "nuclear-reactor",
    energy_required = 8,
    enabled = false,
    ingredients =
    {
      {"concrete", 500},
      {"steel-sheet", 500},
      {"advanced-circuit", 500},
      {"copper-plate", 500}
    },
    result = "nuclear-reactor",
    requester_paste_multiplier = 1
  },
			{	
		type = "recipe",
		name = "primitive-transport-belt",
		enabled = true,
		ingredients =
		{
			{"iron-gear-wheel", 1},
			{"wood", 1},
		},
		result = "primitive-transport-belt",
		result_count = 5,
	},
	{	
		type = "recipe",
		name = "primitive-underground-belt",
		energy_required = 2,
		enabled = testing,
		ingredients =
		{
			{"primitive-transport-belt", 3},
			{"iron-gear-wheel", 2}
		},
		result = "primitive-underground-belt",
		result_count = 2,
		
	},
	
	{	
		type = "recipe",
		name = "primitive-splitter",
		energy_required = 2,
		enabled = testing,
		ingredients =
		{
			{"electronic-circuit", 2},
			{"primitive-transport-belt", 2},
			{"iron-gear-wheel", 4}
		},
		result = "primitive-splitter"
	},
	
	--DISABLED TECHS
	
	{	
		type = "recipe",
		name = "transport-belt",
		enabled = false,
		ingredients =
		{
			{"iron-gear-wheel", 1},
			{"iron-plate", 1},
		},
		result = "transport-belt",
		result_count = 2,
	},
		{	
		type = "recipe",
		name = "inserter",
		enabled = false,
		ingredients ={
		{"electronic-circuit", 1},
      {"iron-gear-wheel", 1},
      {"iron-plate", 1}},
		result = "inserter"
		
	},
	{
    type = "recipe",
    name = "lab",
    energy_required = 2,
	enabled = true,
    ingredients =
    {
      {"electronic-circuit", 10},
      {"iron-gear-wheel", 10},
      {"primitive-transport-belt", 8}
    },
    result = "lab"
  },
	
}
)


