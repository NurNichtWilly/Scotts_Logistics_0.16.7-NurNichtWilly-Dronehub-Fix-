--pipe control


script.on_event({defines.events.},
	function(pipeCheck)
		if pipeCheck.tick % 60 == 0 then
		north = {0,1}
		south = {0,-1}
		east = {1,0}
		west = {-1,0}
		pipe_connections = {0,0}
				
		if south == "steel-pipe" then pipe_connections = south
		end
		if north == "steel-pipe" then pipe_connections = north
		end
		if east == "steel-pipe" then pipe_connections = east
		end
		if west == "steel-pipe" then pipe_connections = west
		end
		end
	end
)
